//
//  main.c
//  Knuth
//
//  Created by Shaft on 17/04/2020.
//  Copyright © 2020 Uni. All rights reserved.
//

#include <stdio.h>
#include <time.h>
#include <math.h>
int const lim= 50000000, reps=10000000;
int ai= 0, sz, Srt[lim], Tab[lim+1];
#define BLog2(N) ((sizeof(N)*8) -1 -__builtin_clz(N))
void GenTab(int hi, int sz, int Srt[], int Tab[]) {
    if (hi+hi <= sz)
        GenTab(hi+hi, sz, Srt, Tab);
    Tab[hi]= Srt[ai++];
    if (hi+hi+1 <= sz)
        GenTab(hi+hi+1, sz, Srt, Tab);
}
void KGenG(int Tab2[]) {
   int di,ki,lim;
   di= 1 << (BLog2(sz) +1);
   lim= di + di;
   while (++di < lim) {
      ki= di >> (__builtin_ffs(di));
      if (ki <= sz) // Note 1
         Tab2[ki]= Srt[ai++];
   }
}
int BinSearch(int Tab[], int srch) {
   int bot= 0, top= sz -1, mid= 0;
   while (top >= bot) {
      mid= (top + bot) >> 1; // Note 1
      if (Tab[mid] > srch)
         top= mid -1;
      else
      if (Tab[mid] < srch)
         bot= mid +1;
      else
         return mid;
   }
   return -mid -1;
}
int BinSearchE(int Tab[], int srch) {
   int bot= 0, top= sz -1, mid= 0;
   if (srch <= Tab[0])
       return (srch < Tab[0] ? -1 : 0); // Note 1
   while (top > bot) {
      mid= (top + bot) >> 1;
      if (Tab[mid] >= srch)
         top= mid;
      else
         bot= mid +1;
   }
   if (Tab[top] == srch)
      return top;
   else
      return -top -1;
}
int BinSearchV(int Tab[], int srch) {
   int del, mid;
   mid= (1 << (BLog2(sz-1))); // Note 1
   if (Tab[mid] < srch) {
      int apx= sz -mid;
      apx= BLog2(apx) + (__builtin_popcount(apx) > 1); // Note 2
      del= 1 << (apx-1);
      mid= sz - del;
   }
   else {
      mid>>= 1;
      del= mid;
   }
   while (del > 1) {
      del= (del & 1) + (del >> 1);
      mid = (Tab[mid] < srch ? mid +del : mid -del);
   }
    return (Tab[mid] == srch ? mid : (mid >0 && Tab[mid-1] == srch ? mid -1 :
                                      (mid < sz && Tab[mid+1] == srch ? mid +1:-mid-1)));
}
int KSearch(int Tab[], int targ) { // Note 1
   int top= Tab[0], ii= 1;
   while (ii <= top) {
      if (Tab[ii] == targ)
         return ii;
      ii= (Tab[ii] < targ) + ii + ii; // Note 2
   }
   return 0;
}
int KSearch15(int Tab[], int targ) {
   int ii;
   if (Tab[1] == targ)
      return 1;
   ii= (Tab[1] < targ) + 2;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //15
   if (Tab[ii] == targ)
      return ii;
   return 0;
}
int KSearch666(int Tab[], int targ) {
   int ii;
   if (Tab[1] == targ)
      return 1;
   ii= (Tab[1] < targ) + 2;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //15
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //255
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (ii <= 666 && Tab[ii] == targ) // Note 3
      return ii;
   return 0;
}
int KSearch9000(int Tab[], int targ) {
   int ii;
   if (Tab[1] == targ)
      return 1;
   ii= (Tab[1] < targ) + 2;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //15
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //255
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //4095
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (ii <= 9000 && Tab[ii] == targ) // Note 3
      return ii;
   return 0;
}
int KSearch2_18(int Tab[], int targ) {
   int ii;
   if (Tab[1] == targ)
      return 1;
   ii= (Tab[1] < targ) + 2;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //15
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //255
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //4095
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //65535
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ) // Note 3
      return ii;
   return 0;
}
int KSearch10_7(int Tab[], int targ) {
   int ii;
   if (Tab[1] == targ)
      return 1;
   ii= (Tab[1] < targ) + 2;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //15
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //255
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //4095
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //65535
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ) // Note 3
      return ii;
   ii= (Tab[ii] < targ) + ii + ii;
   if (Tab[ii] == targ)
      return ii;
   ii= (Tab[ii] < targ) + ii + ii; //2**20
   if (Tab[ii] == targ)
      return ii;
    ii= (Tab[ii] < targ) + ii + ii;
    if (Tab[ii] == targ)
       return ii;
    ii= (Tab[ii] < targ) + ii + ii;
    if (Tab[ii] == targ)
       return ii;
    ii= (Tab[ii] < targ) + ii + ii;
    if (Tab[ii] == targ)
       return ii;
    ii= (Tab[ii] < targ) + ii + ii; //2**24
    if (Tab[ii] == targ)
       return ii;
    /* ii= (Tab[ii] < targ) + ii + ii;
    if (Tab[ii] == targ)
       return ii; */
    ii= (Tab[ii] < targ) + ii + ii;
    if (Tab[ii] == targ)
       return ii;
    ii= (Tab[ii] < targ) + ii + ii;
    if (ii <= 10000000 && Tab[ii] == targ)
       return ii;
    return 0;
}
int KSearchL(int Tab[], int targ) {
   int ii= 1, top= Tab[0];
   while (ii <= top)
      ii= (Tab[ii] <= targ) +ii +ii;
   ii= ii >> __builtin_ffs(ii); // Note 1
   //return (Tab[ii] == targ) *ii; // Note 2
   return (Tab[ii] == targ ? ii : 0);
}
int KSearchT15(int Tab[], int targ) {
   int ii= (Tab[1] <= targ) +2;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= ii >> __builtin_ffs(ii);
   //return (Tab[ii] == targ) *ii;
   return (Tab[ii] == targ ? ii : 0);
}
int KSearchT666(int Tab[], int targ) {
   int ii= (Tab[1] <= targ) +2;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //15
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //255
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   if (ii <= 666)
       ii= (Tab[ii] <= targ) +ii +ii;
   ii= ii >> __builtin_ffs(ii);
   //return (Tab[ii] == targ) *ii;
   return (Tab[ii] == targ ? ii : 0);
}
int KSearchT9000(int Tab[], int targ) {
   int ii= (Tab[1] <= targ) +2;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //15
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //255
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //4095
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   if (ii <= 9000)
       ii= (Tab[ii] <= targ) +ii +ii;
   ii= ii >> __builtin_ffs(ii);
   //return (Tab[ii] == targ) *ii;
   return (Tab[ii] == targ ? ii : 0);
}
int KSearchT2_18(int Tab[], int targ) {
   int ii= (Tab[1] <= targ) +2;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //15
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //255
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //4095
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //65535
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= ii >> __builtin_ffs(ii);
   //return (Tab[ii] == targ) *ii;
   return (Tab[ii] == targ ? ii : 0);
}
int KSearchT10_7(int Tab[], int targ) {
   int ii= (Tab[1] <= targ) +2;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //15
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //255
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //4095
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //65535
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //2**20-1
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; //2**24-1
/* ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii;
   ii= (Tab[ii] <= targ) +ii +ii; */
   if (ii <= 10000000)
       ii= (Tab[ii] <= targ) +ii +ii;
   ii= ii >> __builtin_ffs(ii);
   //return (Tab[ii] == targ) *ii;
   return (Tab[ii] == targ ? ii : 0);
}

const int szs[5]= {15,666,9000,262143,10000000}, szszs= 5;
int dummy(int Tab[], int targ) { return targ;}
void timeit() {
#define timsrch(Search) {\
    for (tx=0; tx<4; tx++) {\
        tt[tx]= clock();\
        for (ii=0;ii<reps;ii++) jj= Search(Tab,Srt[(si=((si +251)%sz))]);\
        tt[tx]= clock() -tt[tx] -bt;\
        tn[tx]= clock();\
        for (ii=0;ii<reps;ii++) jj= Search(Tab,Srt[(si=((si +251)%sz))+1]);\
        tn[tx]= clock() -tn[tx] -bt;\
    }\
    for (tx=1; tx<4; tx++) {\
        if (tt[tx] < tt[0]) tt[0]= tt[tx];\
        if (tn[tx] < tn[0]) tn[0]= tn[tx];\
}\
    printf(#Search"   %6.4f %6.4f\n",(double)tt[0]/CLOCKS_PER_SEC,(double)tn[0]/CLOCKS_PER_SEC);}
        int ii,jj,tx=0, si=0;
        clock_t bt,tt[4],tn[4];
        ai= 0;
        for (ii=1;ii<=sz;ii++)
            Tab[ii-1]= (Srt[ii-1]= ii*3);
     /* GenTab(1, sz, Srt, Tab);
        Tab[0]= sz;
    //for (ii=0;ii<=sz;ii++) printf("%d ",Tab[ii]);
    //printf("\n");
     for (ii=0;ii<sz;ii++) {
            jj= KSearch10_7(Tab,Srt[ii]);
            if (jj <= 0 || Tab[jj] != Srt[ii]) {
            printf("V:%d %d %d %d\n",jj, sz, ii, Srt[ii]);
            tx++;
            if (tx>2) return;
            }
     }
    return; */
        tt[0]= clock();
        for (ii=0;ii<reps;ii++) jj= dummy(Tab,Srt[(si=((si +251)%sz))]);
        bt= clock() -tt[0];
        printf("%d %lu %6.4f\n",sz,BLog2(sz),(double)bt/CLOCKS_PER_SEC);
        timsrch(BinSearch);
        timsrch(BinSearchE);
        timsrch(BinSearchV);
        GenTab(1, sz, Srt, Tab);
        Tab[0]= sz;
        timsrch(KSearch);
        timsrch(KSearchL);
        if (sz == 15) {timsrch(KSearch15);timsrch(KSearchT15);}
        else if (sz == 666) {timsrch(KSearch666);timsrch(KSearchT666);}
        else if (sz == 9000) {timsrch(KSearch9000);timsrch(KSearchT9000);}
        else if (sz == 262143) {timsrch(KSearch2_18);timsrch(KSearchT2_18);}
        else if (sz == 10000000) {timsrch(KSearch10_7);timsrch(KSearchT10_7);}
        else printf("Err %d",sz);
}
int main(int argc, const char * argv[]) {
    int sx;
    for (sx=0;sx<szszs;sx++){
        sz= szs[sx];
        timeit();
    }
    return 0;
}
